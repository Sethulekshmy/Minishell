

#include "ms.h"


char *external_commands[200];
char cmd[20];
int one_time=1;
Slist *head=NULL;
int arr[25]={0};
int arr_flag;
char jobsstr[25];
pid_t delete;
int flag,jobs_flag;
int status, count_stop;
extern char prompt[25],input_string[25];
pid_t child_pid;


void scan_input(char *prompt, char *input_string)
{
    //call the function store the external commands into one array
    signal(SIGINT,my_handler);
    signal(SIGTSTP,my_handler1);
    extract_external_commands(external_commands);
   
    while(1)
    {
        memset(input_string,0,sizeof(input_string));
        // check the background process done or not  
        if(flag)
        {
            //if process is complete delete the last stored value
            // printf("Hello\n");
            while(waitpid(arr[arr_flag-1], &status, WNOHANG)!=0)
            {
                jobs_flag=1;
                delete_at_last(&head);
                arr_flag--;
                if(arr_flag==-1)
                {
                    // printf("Hello\n");
                    memset(arr,0,25);
                    arr_flag=0;
                    flag=0;
                }
                break;
            }
        }
        //print the prompt
        printf("%s ",prompt);
        //read the input string
        scanf("%[^\n]",input_string);
        getchar();
        if(!strcmp(input_string,""))
        {
            continue;
        }
        //validate ps1 or not
        if((validate_ps1(prompt,input_string))==SUCCESS)
        {
            continue;
        }
        
        //get command
        char *command = get_command(input_string);
        if(!strcmp(command,"fg"))
        {
            fore_groung_cont(&head);
            continue;
        }
        if(!strcmp(command,"bg"))
        {
            bg_groung_cont(head);
    
            continue;
        }
        if(!strcmp(command,"jobs"))
        {
            if(jobs_flag)
            {
                printf("[0]  %s Done\n",jobsstr);
                jobs_flag=0;
            }
            print_list(head);
            continue;
        }
        //call check command
        int check_command =check_command_type(command);
        if(check_command == BUILTIN)
        {
            //if builtin call internal command
            execute_internal_commands(input_string);
        }
        else if(check_command==EXTERNAL)
        {
            /*intilaize an array and allocate memory*/
            char *argv[20];
            for(int i=0;i<20;i++)
            {
                argv[i]=malloc(20*sizeof(int));
            }
            char str[25];
            /*copy input_string into one array*/
            strcpy(str,input_string);
            int i=0;
            /*copy word by word separated by space into 2d array*/
            char *ret3=strtok(str," ");
            while(ret3!=NULL)
            {
                strcpy(argv[i++],ret3); 
                ret3=strtok(NULL," ");
            }
            argv[i]=NULL;
            //if it is external check pipe is present or not 
            int k=0,pipe_index=0;
            while(argv[k])
            {
                if(!strcmp(argv[k],"|"))
                {
                    pipe_index=1;
                    break;
                }
                k++;
            }
            //create a child process
            pid_t pid=fork();
            if(pid>0)
            {
                //wait until child terminate
                child_pid=pid;
                waitpid(pid,&status,WUNTRACED);
                child_pid=0;
            }
            else if(pid==0)
            {
                if(pipe_index)
                {
                    //excute n_pipe command
                    n_pipe(argv,i);
                    return ;
                }
                else
                {
                    //excute external commands
                    execute_external_commands(argv);
                }
            }
        }
        //if no command 
        
        else if(check_command==NO_COMMAND)
        {
            printf("%s: command not found\n",input_string);
        }
        //reset input string with 0 
        

    }
}


int validate_ps1(char *prompt, char *input_string)
{
    //intialize a string
    char string[]="PS1=";
    int count=0;
    int i=0;
    //compare string havnig PS1= or not
    while(input_string[i])
    {
        if(input_string[i]==string[i])
        {
            count++;
        }
        else
        {
            break;
        }
        i++;
    }
    //check the string is matching with ps1 or not
    if((input_string[i]!='\0'&&input_string[i]!=' ')&&(count==4))
    {
        char str[100];
        int j=0;
        while(input_string[i]!=' '&&input_string[i])
        {
            str[j++]=input_string[i++];
        }
        str[j]='\0';
        strcpy(prompt,str);
        return SUCCESS;
    }
    //check the string is matching with ps1 or not
    else if((input_string[i]=='\0'&&count==4&&strlen(input_string)==4))
    {
        char str[100];
        int j=0;
        while(input_string[i])
        {
            str[j++]=input_string[i++];
        }
        str[j]='\0';
        strcpy(prompt,str);
        return SUCCESS;
    }
    /*if command not found return no command*/
    else if(count>=1)
    {
        printf("%s: command not found\n",input_string);
        return SUCCESS;
    }
    return FAILURE;
}



char *get_command(char *input_string)
{
    /*get first command*/
    char str[25];
    /*copy the input string*/
    strcpy(str,input_string);
    strcpy(cmd,strtok(str," "));
    /*return the command*/
    return cmd;     
}



void extract_external_commands(char **external_commands)
{
    /*allocate memory for external commands*/
    for(int i=0;i<200;i++)
    {
        external_commands[i]=calloc(25,sizeof(char));
    }
    /*open file*/
    int fd = open("external_cmd.txt",O_RDONLY);
    char buffer;
    int i=0,j=0;
    /*read char by char */
    while(read(fd,&buffer,1))
    {
        if(buffer=='\n')
        {
            external_commands[i][j++]='\0';
            j=0;
            i++;
            continue;
        }
        /*store into 2d array*/
        external_commands[i][j++]=buffer;
    }
}

int check_command_type(char *command)
{
   
    //list of built in commands
    char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
        "set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source",
        "exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", NULL};
    //check whether built in command are not
    int i=0;
    while(builtins[i])
    {
        if(!strcmp(command,builtins[i]))
        {
            //return builtin
            return BUILTIN;
        }
        i++;
    }
    //compare the command is external or not
    i=0;
    while(i<152)
    {
        
        if(!strcmp(command,external_commands[i]))
        {
            //return external
            return EXTERNAL;
        }
        i++;
    }
    //return no command
    return NO_COMMAND;
}


void execute_internal_commands(char *input_string)
{
    char str[25];
    strcpy(str,input_string);
    char *ret=strtok(str," ");
    //if command is exit then exit from the current terminal
    if(!strcmp(ret,"exit"))
    {
        exit(1);
    }
    //if command is pwd print present working directory
    else if(!strcmp(ret,"pwd"))
    {
        char buf[50];
        getcwd(buf,50);
        printf("%s\n",buf);
    }
    //if command is cd change one directory to another 
    else if(!strcmp(ret,"cd"))
    {
        char *ret2=strtok(NULL," ");
        if(ret2==NULL)
        {
            return ;
        }
        chdir(ret2);

    }
    //if command is echo check coditions and print 
    else if(!strcmp(ret,"echo"))
    {
        char *ret1=strtok(NULL,"\0");
        if(ret1==NULL)
        {
            return ;
        }
        if(!strcmp(ret1,"$$"))
        {
            printf("%d\n",getpid());
        }
        else if(!strcmp(ret1,"$?"))
        {
            printf("%d\n",status);
        }
        else if(ret1[0]=='$'&&((ret1[1]>='A'&&ret1[1]<='Z')||(ret[1]>='a'&&ret[1]<='z')))
        {
            char *ret4=strtok(ret1,"$");
            char *ret5=getenv(ret4);
            if(ret5!=NULL)
            {
                printf("%s\n",ret5);
                return ;
            }
            printf("\n");
        }
        else
        {
            printf("%s\n",ret1);
        }
    }
}



void execute_external_commands(char **argv)
{

    /*excute commands*/
    execvp(argv[0],argv+0);

}

void n_pipe(char **argv,int size)
{
    int cmd_pos[size];
        int i=0,j=0;
        cmd_pos[j]=0;
        int command_count=0;
        //store all the pipe index
        while(argv[i])
        {
            if(!strcmp(argv[i],"|"))
            {
                cmd_pos[++j]=i+1;
                argv[i]=NULL;
                command_count++;
            }
            i++;
        }
        
        int fd[2];
        for(int i=0;i<=command_count;i++)
        {
            if(i!=command_count)
            {
                //create a pipe
                pipe(fd);
            }
            //create a child process
            pid_t pid=fork();
            //parent
            if(pid>0)
            {
                if(i!=command_count)
                {
                    close(fd[1]);
                    dup2(fd[0],0);
                    close(fd[0]);
                   
                }
                //wait until the child is completed
                wait(NULL);
            }
            //child
            else if(pid==0)
            {
                if(i!=command_count)
                {
                    close(fd[0]);
                    dup2(fd[1],1);
                }
                //change command
                execvp(argv[cmd_pos[i]],(argv+cmd_pos[i]));
            }
        }

}


void my_handler(int signum)
{

    if(child_pid!=0)
    {
        //kill the particular child process
        kill(child_pid,SIGINT);
        printf("\n");
    }
    else if(child_pid==0)
    {
        //change the prompt
        printf("\n%s ",prompt);
        fflush(stdout);
        
    }

}

void my_handler1(int signum)
{
    if(child_pid!=0)
    {
        //kill the particular child process
        kill(child_pid,SIGTSTP);
        
        fflush(stdout);
        count_stop++;
        printf("[%d]+  Stopped      %s\n",count_stop,input_string);
        fflush(stdout);
        //insert at last
        insert_at_last(&head,child_pid,input_string);
           
    }
    else if(child_pid==0)
    {
    
        //change the prompt
        printf("\n%s ",prompt);
        fflush(stdout);
        
        
    } 
}

void insert_at_last(Slist **head,int child_pid,char *input_string)
{
    //create a node 
    Slist *new = (Slist *)malloc(sizeof(Slist));
    //store the data
    new->pid=child_pid;
    strcpy(new->command,input_string);
    new->link=NULL;
    //if head NULL cotinued with new
    if((*head)==NULL)
    {
         *head=new;
         return;
    }
    //if head is not NULL 
    Slist *temp=*head;
    //traverse the list 
    while(temp->link)
    {
        temp=temp->link;
    }
    //add data into the last link
    temp->link=new;
    return;
}


void delete_at_last(Slist **head)
{
    //if head NULL cotinued with new
    if(*head==NULL)
    {
        return;
    }
    //if head NULL cotinued with new
    if((*head)->link==NULL)
    {
        strcpy(jobsstr,(*head)->command);
        free(*head);
        *head=NULL;
        return;
    }
    //if store head into a temp
    Slist *temp=*head;
    Slist *prev=NULL;
    //traverse through the list
    while(temp->link)
    {
        prev=temp;
        temp=temp->link;
    }
    //delete the list
    prev->link=NULL;
    strcpy(jobsstr,temp->command);
    free(temp);
    return;
}


void print_list(Slist *head)
{
    //if head is NULL print bash
    if(head==NULL)
    {
        printf("bash: jobs: current: no such job\n");
        return;
    }
    int i=1;
    //print the particular list
    int j=0;
    while(head)
    {
        int flag1=0;
        j=0;
        while(arr[j]){
            if(head->pid==arr[j])
            {
                    printf("[%d] Running           %s\n",i,head->command);
                    flag1=1;
                    break;
            }
            j++;
        }
        if(flag1==0)
        printf("[%d] Stopped           %s\n",i,head->command);
        i++;
        head=head->link;
    }
}



void fore_groung_cont(Slist **head)
{
    //Traverse until last node
    Slist *temp = *head;
    Slist *prev = NULL;
    while(temp->link !=NULL&&temp->link->pid!=delete)
    {
        prev = temp;
        temp = temp->link;
    }
    //print the process
    printf("%s\n",temp->command);
    //Continue the stopped process
    kill(temp->pid,SIGCONT);
    //To track the status of continuing process
    int status;
    //Wait until the process getting done
    waitpid(temp->pid,&status,WUNTRACED);
    //Check if process is completed or not, if yes remove from SLL
    if(status == 0)
    {
        //If 1st node
        if(prev == NULL)
        {
            *head = NULL;
        }
        else
        {
            //Remove the last node as process is completed
            prev->link = NULL;
        }
        //Free the last node
        free(temp);
    }
    
    
}

void bg_groung_cont(Slist *head)
{
    //if head is NULL print bash
    if(head == NULL)
    {
        printf("bash: fg: current: no such job\n");
        arr_flag=0;
        return;
    }
    //if traverse through the list
    while(head->link&&(head->link->pid)!=delete)
    {
        head=head->link;
    }
    //if traverse the delete
    printf("%s\n",head->command);
    printf("%d\n",head->pid);
    delete = head->pid;
    arr[arr_flag++]=delete;
    //continue the previous process
    kill(head->pid, SIGCONT); 
    flag=1;   
}