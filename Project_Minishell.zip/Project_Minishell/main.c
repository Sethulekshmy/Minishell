
#include "ms.h"
char prompt[25]="minishell$";
char input_string[25];

int main()
{
    //first we have to clear the termainal
    system("clear");
    //call the function 
    scan_input(prompt, input_string);
}